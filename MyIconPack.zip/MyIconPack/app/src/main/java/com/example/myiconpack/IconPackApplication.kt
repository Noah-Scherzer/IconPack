package com.example.myiconpack

import android.app.Application

class IconPackApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // TODO: Optional init code
    }
}
